
class AdminDemo {
	
	/**
	 * Method main
	 *
	 *
	 * @param args
	 *
	 */
	public static void main(String[] args) {
		
		new AdminLogin(new Quiz());
	}	
}
