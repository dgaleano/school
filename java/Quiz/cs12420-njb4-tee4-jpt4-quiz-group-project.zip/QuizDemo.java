
class QuizDemo {
	
	/**
	 * Method main
	 *
	 *
	 * @param args
	 *
	 */
	public static void main(String[] args) {
		new QuizGUI();
	}	
}
